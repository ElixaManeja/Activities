/** Automatically generated file. DO NOT MODIFY */
package com.example.listviewcaller;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}