package com.example.picgrid;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

public class UpdatePersonActivity extends Activity {

	ImageView iv;
	EditText txtName;
	ImageButton btnSave,btnCancel;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.iv=(ImageView) this.findViewById(R.id.imageView1);
		this.txtName=(EditText)this.findViewById(R.id.editText1);
	}

	
	
}
